# DJTONI — Página web profesional

## Cómo abrirla
1. Descomprime el archivo ZIP.
2. Abre `index.html` en tu navegador.
3. Para publicarla, sube los tres archivos (`index.html`, `style.css` y `dj-toni.jpg`) a tu hosting.

## Incluye
- Foto de DJ Toni.
- Teléfono: 657342322.
- Instagram: @djtoniioficial.
- Instagram: @antoonio_ramireez.
- TikTok: @djtonioficial.
- SoundCloud: DJTONIOFICIAL.
- Apartado de música.
- Formulario de contacto para sugerencias, precios, contrataciones y colaboraciones.

## Nota sobre el formulario
El formulario utiliza `mailto:` y abre la aplicación de correo del visitante. Para recibir mensajes desde cualquier dispositivo de forma más fiable, puedes conectarlo posteriormente a un servicio de formularios o a un backend.
